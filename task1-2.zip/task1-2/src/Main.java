public class Main {
    public static void main(String[] args) {
        // Создаем объект Area
        Area area1 = new Area("Центральный парк", "Северная Америка", "Нью-Йорк", 3.41f);

        // Создаем отчет о погоде на данной территории
        WeatherOnArea weatherReport1 = new WeatherOnArea("2023-10-15", area1, "Солнечно", 22.5f);

        // Отображаем информацию о погоде
        weatherReport1.displayWeather();
    }
}
