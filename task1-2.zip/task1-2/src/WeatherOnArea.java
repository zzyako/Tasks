// Класс WeatherOnArea, представляющий погодные условия на территории
public class WeatherOnArea extends WeatherReport {
    private Area area;
    private String weatherDescription;
    private float temperature; // Температура в градусах Цельсия

    public WeatherOnArea(String date, Area area, String weatherDescription, float temperature) {
        super(date);
        this.area = area;
        this.weatherDescription = weatherDescription;
        this.temperature = temperature;
    }

    // Геттеры и сеттеры
    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public String getWeatherDescription() {
        return weatherDescription;
    }

    public void setWeatherDescription(String weatherDescription) {
        this.weatherDescription = weatherDescription;
    }

    public float getTemperature() {
        return temperature;
    }

    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    // Реализация абстрактного метода displayWeather
    @Override
    public void displayWeather() {
        System.out.println("Дата: " + getDate());
        area.displayInfo();
        System.out.println("Погодные условия: " + weatherDescription);
        System.out.println("Температура: " + temperature + "°C");
    }
}
