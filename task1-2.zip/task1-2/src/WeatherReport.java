// Абстрактный класс для отчетов о погоде
public abstract class WeatherReport {
    private String date;

    public WeatherReport(String date) {
        this.date = date;
    }

    // Геттер для даты
    public String getDate() {
        return date;
    }

    // Абстрактный метод для отображения отчета о погоде
    public abstract void displayWeather();
}
