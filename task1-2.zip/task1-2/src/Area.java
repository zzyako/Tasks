// Класс Area, представляющий территорию
public class Area extends Location {
    private String continent;
    private String city;
    private float areaSize; // Площадь в квадратных километрах

    public Area(String name, String continent, String city, float areaSize) {
        super(name);
        this.continent = continent;
        this.city = city;
        this.areaSize = areaSize;
    }

    // Геттеры и сеттеры
    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public float getAreaSize() {
        return areaSize;
    }

    public void setAreaSize(float areaSize) {
        this.areaSize = areaSize;
    }

    // Реализация абстрактного метода displayInfo
    @Override
    public void displayInfo() {
        System.out.println("Территория: " + getName());
        System.out.println("Континент: " + continent);
        System.out.println("Город: " + city);
        System.out.println("Площадь: " + areaSize + " кв.км");
    }
}
